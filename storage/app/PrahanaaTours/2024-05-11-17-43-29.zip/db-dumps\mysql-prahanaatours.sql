
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `age_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `age_price` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tour_id` int(10) DEFAULT NULL,
  `age_type_id` int(10) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `status` int(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `age_price` WRITE;
/*!40000 ALTER TABLE `age_price` DISABLE KEYS */;
INSERT INTO `age_price` VALUES (1,7,1,'39',1);
/*!40000 ALTER TABLE `age_price` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `age_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `age_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `age_type_name` varchar(100) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `age_type` WRITE;
/*!40000 ALTER TABLE `age_type` DISABLE KEYS */;
INSERT INTO `age_type` VALUES (1,'1 To 8',1);
/*!40000 ALTER TABLE `age_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT 0,
  `tour_id` int(10) DEFAULT NULL,
  `agewise_count` int(10) DEFAULT NULL,
  `age_price_id` int(10) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tour_id` int(10) DEFAULT NULL,
  `tour_date` varchar(20) DEFAULT NULL,
  `no_of_person` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `booking_date` varchar(20) DEFAULT NULL,
  `pickup_location` varchar(50) DEFAULT NULL,
  `complete` varchar(10) DEFAULT '0',
  `order_status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pickup_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pickup_location` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pickup_location_name` varchar(100) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pickup_location` WRITE;
/*!40000 ALTER TABLE `pickup_location` DISABLE KEYS */;
/*!40000 ALTER TABLE `pickup_location` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tours_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tours_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) DEFAULT NULL,
  `package_id` int(10) NOT NULL,
  `photo` varchar(20) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tours_images` WRITE;
/*!40000 ALTER TABLE `tours_images` DISABLE KEYS */;
INSERT INTO `tours_images` VALUES (1,NULL,1,'1.png','Active'),(2,NULL,2,'2.png','Active'),(3,NULL,3,'3.png','Active'),(4,NULL,4,'4.png','Active'),(5,NULL,5,'5.png','Active'),(6,NULL,6,'6.png','Active'),(7,NULL,7,'7.png','Active');
/*!40000 ALTER TABLE `tours_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tours_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tours_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `packages_name` varchar(200) DEFAULT NULL,
  `price` varchar(10) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `tour_type` int(1) DEFAULT NULL,
  `photo` varchar(300) DEFAULT NULL,
  `tour_date` varchar(15) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tours_packages` WRITE;
/*!40000 ALTER TABLE `tours_packages` DISABLE KEYS */;
INSERT INTO `tours_packages` VALUES (1,'aaaaaaaaa','35','<p>sssssssssssssssssss</p>',1,NULL,'2024-04-18','Active'),(2,'gggggg','35','<p>gggggggggggggggg</p>',2,NULL,'2024-04-18','Active'),(3,'dddddddddd','39','<p>ddd</p>',1,NULL,'2024-04-18','Active'),(4,'fffff','35','<p>ddd</p>',2,NULL,'2024-04-18','Active'),(5,'ffffffffffff','39','<p>fffff</p>',2,NULL,'2024-04-18','Active'),(6,'ffffffffffff','1','<p>ddddd</p>',2,NULL,'2024-04-18','Active'),(7,'ff','35','<p>fffff</p>',1,NULL,'2024-04-18','Active');
/*!40000 ALTER TABLE `tours_packages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `travel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `travel_name` varchar(200) DEFAULT NULL,
  `travel_price` varchar(50) DEFAULT NULL,
  `travel_no` varchar(20) DEFAULT NULL,
  `seats` int(10) DEFAULT NULL,
  `ac` varchar(10) DEFAULT NULL,
  `colour` varchar(10) DEFAULT NULL,
  `travel_image` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `travel` WRITE;
/*!40000 ALTER TABLE `travel` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `travel_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_no` int(11) DEFAULT NULL,
  `travel_id` int(10) DEFAULT NULL,
  `photo` varchar(20) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `travel_images` WRITE;
/*!40000 ALTER TABLE `travel_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_type` (
  `id` int(11) NOT NULL,
  `user_type` varchar(50) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_type` WRITE;
/*!40000 ALTER TABLE `user_type` DISABLE KEYS */;
INSERT INTO `user_type` VALUES (1,'Superadmin','1');
/*!40000 ALTER TABLE `user_type` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type_id` int(11) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `full_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `cpassword` varchar(1000) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user_photo` varchar(500) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `log_id` int(11) DEFAULT NULL,
  `device_id` varchar(500) DEFAULT NULL,
  `wallet` decimal(10,2) DEFAULT 0.00,
  `colour` int(11) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'RJ01N001','Superadmin','universekannan@gmail.com','$2a$12$OiQen7W52Xu.JF9L9xBD6OeJYuvCCfKk2I2Wlp7cpA/WZXO3RzRtm','12345678','1','7598984380','user.jpg','Active',NULL,1,NULL,52616.67,2),(2,3,NULL,'Galaxy Kannan','kannan@gmail.com','$2y$10$cPbQZZS9TX5B/xZIb2Cp8eTjDKmmb6FsBT2BIFlJMiv5v3TRZwYC6','12345678',NULL,'9443587282',NULL,NULL,NULL,NULL,NULL,0.00,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

